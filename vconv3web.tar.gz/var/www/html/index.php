<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd"> 
<html> 
<head> 
    <meta http-equiv="content-type" content="text/html;charset=ISO-8859-1"> 
    <title>Gestione di AVconv</title>   
    <link href="stile.css" rel="stylesheet" type="text/css">
</head> 

<body> 
<table style="border:1px blue" border="1" >
<tr><td>
<?php
	$file = fopen("/vconv2/parametri.txt", "r");
	$ver=fgets($file);
	$vbit=fgets($file);
	$abit=fgets($file);
	$fps=fgets($file);
	$qual=fgets($file);
	$sub=fgets($file);
    //	   ultrafast, superfast, veryfast, faster, fast, medium, slow, slower, veryslow, placebo
?>

<h1>Parametri di AVConv v<?php echo $ver ?></h1> 
    <pre>
    <form method="GET" action="inviato.php">
	Video bitrate : <input type="text" name="vbit" value="<?php echo $vbit; ?>"  /> <br>
	Audio bitrate : <input type="text" name="abit" value="<?php echo $abit; ?>"  /> <br>
	fps           : <input type="text" name="fps" value="<?php echo $fps; ?>"  /> <br>
	Qualita'      : <select name="qual" >
				<option value="<?php echo $qual; ?>" selected> <?php echo $qual; ?> </option>
        	   		<option value="ultrafast">ultrafast</option>
				<option value="superfast">superfast</option>
				<option value="veryfast">veryfast</option>
				<option value="faster">faster</option>
				<option value="fast">fast</option>
				<option value="medium">medium</option>
				<option value="slow">slow</option>
				<option value="veryslow">veryslow</option>
        		</select><br>
         <input type="hidden" name="ver" value="<?php echo $ver; ?>"/>
	Sottocartella  : <input type="checkbox" name="sub" checked="<?php echo $sub; ?>">  <br>
	<center>
       <input type=submit value="INVIA"></center>
</form> 
</td></tr>
<tr><td>
 <iframe src="js-logtail/index.html" style="border:2px red"  width="800" height="600" ></iframe>
</td></tr>

</table>

</body> 
</html>

